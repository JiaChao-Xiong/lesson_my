<template>
    <div>
        Add
    </div>
</template>

<script>
export default {
    setup () {
        

        return {}
    }
}
</script>

<style lang="stylus" scoped>

</style>